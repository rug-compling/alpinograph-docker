package main

const VERSION = 8
