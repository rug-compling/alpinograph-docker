package main

const VERSION = 6
