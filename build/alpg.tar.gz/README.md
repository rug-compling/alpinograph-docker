# AlpinoGraph

![Technology Readiness Stage 4/4 - The technology is complete, stable and deployed in production scenarios for end-users](https://w3id.org/research-technology-readiness-levels/Stage4Complete.svg)

Metadata: https://rug-compling.github.io/alpinograph/

Bronbestanden voor [AlpinoGraph](https://urd2.let.rug.nl/~kleiweg/alpinograph/)
