package dbxml
// #cgo CFLAGS: -I/my/opt/dbxml-6.1.4-patch_26647/include
// #cgo CXXFLAGS: -I/my/opt/dbxml-6.1.4-patch_26647/include
// #cgo LDFLAGS: -L/my/opt/dbxml-6.1.4-patch_26647/lib -Wl,-rpath=/my/opt/dbxml-6.1.4-patch_26647/lib
import "C"
