// +build !cgo

// something to build without cgo

package dbxml

func dummy() {
}
