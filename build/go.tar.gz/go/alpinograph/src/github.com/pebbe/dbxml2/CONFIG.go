package dbxml
// #cgo CFLAGS: -I/my/opt/dbxml-rug-compling/include
// #cgo CXXFLAGS: -I/my/opt/dbxml-rug-compling/include
// #cgo LDFLAGS: -L/my/opt/dbxml-rug-compling/lib -Wl,-rpath=/my/opt/dbxml-rug-compling/lib
import "C"
